from fastapi import FastAPI, HTTPException
import httpx
from collections import deque

# Create FastAPI app
app = FastAPI()

# API Mapping for different number types
API_URLS = {
    "p": "http://20.244.56.144/evaluation-service/primes",
    "f": "http://20.244.56.144/evaluation-service/fibo",
    "e": "http://20.244.56.144/evaluation-service/even",
    "r": "http://20.244.56.144/evaluation-service/rand"
}

# 🔑 Replace this with your actual API key
API_KEY = "AIzaSyAoljZu8FUBwdGXcVL1d_llWkOCHLvC9m4"

# Sliding Window Configuration
WINDOW_SIZE = 10
window = deque(maxlen=WINDOW_SIZE)

# Function to fetch numbers from the external API
async def fetch_numbers(api_url: str):
    try:
        async with httpx.AsyncClient(timeout=2) as client:
            headers = {"Authorization": f"Bearer {API_KEY}"}  # 🔑 Add API key
            response = await client.get(api_url, headers=headers)
            response.raise_for_status()
            data = response.json()
            return data.get("numbers", [])
    except (httpx.RequestError, httpx.HTTPStatusError, httpx.TimeoutException):
        return []

# API Endpoint: /numbers/{numberid}
@app.get("/numbers/{numberid}")
async def get_numbers(numberid: str):
    if numberid not in API_URLS:
        raise HTTPException(status_code=400, detail="Invalid number ID")
    
    prev_state = list(window)
    new_numbers = await fetch_numbers(API_URLS[numberid])

    # Filter out duplicates
    unique_numbers = [num for num in new_numbers if num not in window]

    # Add to the sliding window
    window.extend(unique_numbers)

    # Compute average
    avg = round(sum(window) / len(window), 2) if window else 0.0

    return {
        "windowPrevState": prev_state,
        "windowCurrState": list(window),
        "numbers": new_numbers,
        "avg": avg
    }

# Run the server
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=9876)
